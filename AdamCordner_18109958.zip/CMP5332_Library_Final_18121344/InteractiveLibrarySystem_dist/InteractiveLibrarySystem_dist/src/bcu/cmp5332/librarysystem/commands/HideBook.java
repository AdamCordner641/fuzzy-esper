package bcu.cmp5332.librarysystem.commands;

import bcu.cmp5332.librarysystem.model.Book;
import bcu.cmp5332.librarysystem.model.Library;
import bcu.cmp5332.librarysystem.data.LibraryData;
import bcu.cmp5332.librarysystem.main.LibraryException;

import java.io.IOException;
import java.time.LocalDate;

/**
 * Hides, i.e. "deletes", a book from the library.
 *
 */
public class HideBook implements Command {
	
	/**
	 * The ID of the book being hidden.
	 */
	private final int id;

    /**
     * Creates a new HideBook object with the following parameters:
     * @param id The ID of the book being hidden.
     */
    public HideBook(int id) {
        this.id = id;
    }
	
    /**
     * Hides a book from the library.
     * Gets the book ID from the HideBook object.
     * @param library The library storing the books and patrons.
     * @param currentDate The current date.
     */
    @Override
    public void execute(Library library, LocalDate currentDate) throws LibraryException {
        Book book = library.getBookByID(id);
        book.hideBook();
        try {
			LibraryData.store(library);
		} catch (IOException e) {
			e.printStackTrace();
		}
    }
}
