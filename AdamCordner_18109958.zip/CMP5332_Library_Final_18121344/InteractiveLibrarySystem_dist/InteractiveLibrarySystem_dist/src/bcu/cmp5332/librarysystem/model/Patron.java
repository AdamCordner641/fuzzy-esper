package bcu.cmp5332.librarysystem.model;

import bcu.cmp5332.librarysystem.main.LibraryException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Represents a patron.
 * A patron can borrow a book.
 */
public class Patron {
    
    /**
     * The unique ID of the patron.
     */
    private int id;
    /**
     * The full name of the patron.
     */
    private String name;
    /**
     * The phone number of the patron.
     */
    private String phone;
    /**
     * Lists books currently on loan by the patron.
     */
    private List<Book> books = new ArrayList<>();
    /**
     * The maximum number of books which a patron can have on loan at a time.
     */
    private final int limit = 5;
    /**
     * Denotes if the patron is hidden or not from the system.
     */
    private boolean hidden;
    
    /**
     * Creates a new patron with the following parameters:
     * @param id This is the unique ID of the patron.
     * @param name This is the patron's full name.
     * @param phone This is the patron's phone number.
     * @param books This is the list of books currently on loan by the patron.
     * @param hidden This denotes if the patron is hidden or not from the system.
     */
    public Patron(int id, String name, String phone, List<Book> books, boolean hidden) {
    	this.id = id;
    	this.name = name;
    	this.phone = phone;
    	this.books = books;
    	this.hidden = hidden;
    }
    
    /**
     * Get if the patron is hidden or not from the system.
     * @return if the patron is hidden or not from the system.
     */
    public boolean isHidden() {
    	return this.hidden;
    }
    /**
     * Changes the hidden status of the patron to true.
     */
    public void hidePatron() {
    	if(this.books.isEmpty()) {
    		this.hidden = true;
    		System.out.println("Patron #" + this.getId() + " has been removed.");
    	}else {
    		System.out.println("Cannot remove Patron #" + this.getId() + ". This patron has books on loan.");
    	}
    	
    }
    
    /**
     * Get the patron's name.
     * @return the patron's name.
     */
    public String getName() {
    	return this.name;
    }
    
    /**
     * Get the patron's unique ID.
     * @return the patron's unique ID.
     */
    public int getId() {
    	return this.id;
    }
    
    /**
     * Get the patron's phone number.
     * @return the patron's phone number.
     */
    public String getPhone() {
    	return this.phone;
    }
    
    /**
     * Get the list of books on loan by the patron.
     * @return the list of books on loan by the patron.
     */
    public List<Book> getLoans(){
    	return this.books;
    }
    
    /**
     * Get a string containing the books which the patron currently has on loan.
     * @return a string containing the books which the patron currently has on loan.
     */
    public String getLoansAsString() {
    	String loans = "";
        for(Book loan : this.books) {
        	if(loans.isEmpty()) {
        		loans += loan.getId();
        	}else {
        		loans += "," + loan.getId();
        	}
        }
        return loans;
    }
    
    /**
     * Get a string containing all of this loan's current and previous details.
     * @return a string containing all of this loan's current and previous details.
     */
    public String getLoanDetails() {
    	String loans;
    	if(this.books.isEmpty()) {
	    	loans = "No books on loan";
    	}else {
    		loans = "Books on Loan:\n";
	        for(Book loan : this.books) {
	        	loans += "\n" + loan.getTitle() + ". Return Date: " + loan.getLoan().getDueDate();
	        }
    	}
        return loans;
    }
    
    /**
     * Get a string containing this patron's unique ID, full name, phone number, and list of current loans.
     * @return a string containing this patron's unique ID, full name, phone number, and list of current loans.
     */
    public String getPatrons() {
    	return "Patron #" + id + " - " + name + "\n\tPhone Number: " + phone
    			+ "\nOn Loan: " + getLoansAsString();
    }
    
    /**
     * Loan the specified book to this patron.
     * @param book The book being loaned.
     * @param dueDate The due date for the loan.
     * @throws LibraryException
     */
    public void borrowBook(Book book, LocalDate dueDate) throws LibraryException {
    	if(book.isHidden()) {
    		System.out.println("Sorry, Book: " + book.getTitle() + " no longer exists.");
    	}else if(this.isHidden()) {
    		System.out.println("Sorry, Patron: " + this.getName() + " no longer exists.");
    	}else if(this.books.size() >= limit) { 
    		System.out.println("Sorry, maximum number of books already on loan.");
    	}else if(book.isOnLoan()) {
    		System.out.println("Sorry, " + book.getTitle() + " is already on loan.");
    	}else {
    		Loan loan = new Loan(this, book, LocalDate.now(), dueDate, null, true); //return date will be null & loan active will always be true when first borrowing 
        	book.setLoan(loan);
        	this.addBook(book);
        	System.out.println(book.getTitle() + " borrowed by " + this.name + ".\nReturn date: " + book.getDueDate());
    	}
    }	
    
    /**
     * Renew this patron's loan on this book.
     * @param book The book being loaned.
     * @param dueDate The due date of the loan.
     * @throws LibraryException
     */
    public void renewBook(Book book, LocalDate dueDate) throws LibraryException {
    	book.getLoan().setDueDate(dueDate);
    	System.out.println("Book renewed. New Return date: " + dueDate);
    }

    /**
     * Return this book's loan.
     * @param book The book being returned.
     * @throws LibraryException
     */
    public void returnBook(Book book) throws LibraryException {
    	book.returnToLibrary();
    	this.books.remove(book);
    	System.out.println("Book Returned");
    }
    
    public void addBook(Book book) {
    	this.books.add(book);
    }
}
