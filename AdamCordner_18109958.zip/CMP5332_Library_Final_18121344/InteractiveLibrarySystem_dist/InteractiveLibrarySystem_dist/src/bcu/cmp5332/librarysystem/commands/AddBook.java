package bcu.cmp5332.librarysystem.commands;

import bcu.cmp5332.librarysystem.model.Book;
import bcu.cmp5332.librarysystem.model.Library;
import bcu.cmp5332.librarysystem.data.LibraryData;
import bcu.cmp5332.librarysystem.main.LibraryException;

import java.io.IOException;
import java.time.LocalDate;


/**
 * Adds a book to the library.
 *
 */
public class AddBook implements Command {

    /**
     * The title of the book.
     */
    private final String title;
    /**
     * The author of the book.
     */
    private final String author;
    /**
     * The publication year of the book.
     */
    private final String publicationYear;
    /**
     * The publisher of the book.
     */
    private final String publisher;

    /**
     * Creates a new AddBook object with the following parameters:
     * @param title The title of the book.
     * @param author The author of the book.
     * @param publisher The publisher of the book.
     * @param publicationYear The publication year of the book.
     */
    public AddBook(String title, String author, String publisher, String publicationYear) {
        this.title = title;
        this.author = author;
        this.publisher = publisher;
        this.publicationYear = publicationYear;
    }
    
    /**
     * Adds a book to the library.
     * Autogenerates a new unique ID for the book.
     * Gets title, author, publisher, and publication year from the AddBook object.
     * Defaults status of book as hidden to false.
     * @param library The library storing the books and patrons.
     * @param currentDate The current date.
     */
    @Override
    public void execute(Library library, LocalDate currentDate) throws LibraryException {
        int lastIndex = library.getBooks().size() - 1;
        int maxId = library.getBooks().get(lastIndex).getId();
        Book book = new Book(++maxId, title, author, publisher, publicationYear, false);
        library.addBook(book);
        System.out.println("Book #" + book.getId() + " added.");
        try {
			LibraryData.store(library);
		} catch (IOException e) {
			e.printStackTrace();
		}
    }
}
