package bcu.cmp5332.librarysystem.data;

import bcu.cmp5332.librarysystem.main.LibraryException;
import bcu.cmp5332.librarysystem.model.*;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class LoanDataManager implements DataManager {
    
    public final String RESOURCE = "./resources/data/loans.txt";
    
    DateTimeFormatter formatter = DateTimeFormatter.BASIC_ISO_DATE;

    @Override
    public void loadData(Library library) throws IOException, LibraryException {
        // TODO: implementation here
    	try(Scanner sc = new Scanner(new File(RESOURCE))){
    		int line_idx = 1;;
    		while (sc.hasNextLine()) {
    			String line = sc.nextLine();
    			String[] properties = line.split(SEPARATOR, -1);
    			try {
    				int patronID = Integer.parseInt(properties[0]);
    				Patron patron = library.getPatronByID(patronID);
    				int bookID = Integer.parseInt(properties[1]);
    				Book book = library.getBookByID(bookID);
    				String startDateText = properties[2];
    				LocalDate startDate = LocalDate.parse(startDateText, formatter);
    				String endDateText = properties[3];
    				LocalDate endDate = LocalDate.parse(endDateText, formatter);
    				String returnDateText = properties[4];
    				LocalDate returnDate;
    				if(!returnDateText.isEmpty()) {
    					returnDate = LocalDate.parse(returnDateText, formatter);
    				}else {
    					returnDate = null; 
    				}
                    boolean loanActive = Boolean.parseBoolean(properties[5]);
    				Loan loan = new Loan(patron, book, startDate, endDate, returnDate, loanActive); 
    				book.setLoan(loan);
    			} catch (NumberFormatException ex) {
    				throw new LibraryException("Unable to parse loan from" + properties[0] + " on line " + line_idx
                            + "\nError: " + ex);
    			}
    			line_idx++;
    		}
    	}
    }

    @Override
    public void storeData(Library library) throws IOException {
        // TODO: implementation here
    	try(PrintWriter out = new PrintWriter(new FileWriter(RESOURCE))){
    		for (Book book : library.getBooks()) {
    			for(Loan loan : book.getLoans()) {
	    			if(loan != null){
		    			out.print(loan.getPatron().getId() + SEPARATOR);
		    			out.print(loan.getBook().getId() + SEPARATOR);
		    			out.print(loan.getStartDate().format(formatter) + SEPARATOR);
		    			out.print(loan.getDueDate().format(formatter) + SEPARATOR);
		    			if (loan.getReturnDate() != null){
		    				out.print(loan.getReturnDate().format(formatter) + SEPARATOR);
		    			}else {
		    				out.print(SEPARATOR);
		    			}
		    			out.print(loan.getLoanActive() + SEPARATOR);
		    			out.println();
	    			}
    			}
    		}
    	}
    }
    
}
