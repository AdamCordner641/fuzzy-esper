package bcu.cmp5332.librarysystem.model;

import bcu.cmp5332.librarysystem.main.LibraryException;
import java.util.*;

/**
 * Represents the library of books and patrons.
 * The library stores all books and patrons.
 */
public class Library {
    
    /**
     * The period of time for which a book is loaned.
     */
    private final int loanPeriod = 7;
    /**
     * Lists all patrons.
     */
    private final Map<Integer, Patron> patrons = new TreeMap<>();
    /**
     * Lists all books.
     */
    private final Map<Integer, Book> books = new TreeMap<>();

    /**
     * Get the period of time for which a book is loaned.
     * @return the period of time for which a book is loaned.
     */
    public int getLoanPeriod() {
        return loanPeriod;
    }

    /**
     * Get the list of books.
     * @return the list of books.
     */
    public List<Book> getBooks() {
        List<Book> out = new ArrayList<>(books.values());
        return Collections.unmodifiableList(out);
    }
    
    /**
     * Get the list of patrons.
     * @return the list of patrons.
     */
    public List<Patron> getPatrons() {
        List<Patron> out = new ArrayList<>(patrons.values());
        return Collections.unmodifiableList(out);
    }
 
    /**
     * Searches for and returns the book which matches the given unique ID.
     * @param id The given unique ID.
     * @return the book which matches the given unique ID.
     * @throws LibraryException if there is no book which matches the given unique ID.
     */
    public Book getBookByID(int id) throws LibraryException {
        if (!books.containsKey(id)) {
            throw new LibraryException("There is no such book with that ID.");
        }
        return books.get(id);
    }

    /**
     * Searches for and returns the patron which matches the given unique ID.
     * @param id The given unique ID.
     * @return the patron which matches the given unique ID.
     * @throws LibraryException if there is no patron which matches the given unique ID.
     */
    public Patron getPatronByID(int id) throws LibraryException {
    	if (!patrons.containsKey(id)) {
            throw new LibraryException("There is no such patron with that ID.");
        }
        return patrons.get(id);
    }

    /**
     * Adds a book to the list of books.
     * @param book The book being added to the list of books.
     * @throws IllegalArgumentException if the book being added to the list of books is already within the list of books.
     */
    public void addBook(Book book) {
        if (books.containsKey(book.getId())) {
            throw new IllegalArgumentException("Duplicate book ID.");
        }
        books.put(book.getId(), book);
    }

    /**
     * Adds a patron to the list of patrons.
     * @param patron The patron being added to the list of patrons.
     * @throws IllegalArgumentException if the patron being added to the list of patrons is already within the list of patrons.
     */
    public void addPatron(Patron patron) {
    	if (patrons.containsKey(patron.getId())) {
            throw new IllegalArgumentException("Duplicate patron ID.");
        }
        patrons.put(patron.getId(), patron);
    }
    
}
