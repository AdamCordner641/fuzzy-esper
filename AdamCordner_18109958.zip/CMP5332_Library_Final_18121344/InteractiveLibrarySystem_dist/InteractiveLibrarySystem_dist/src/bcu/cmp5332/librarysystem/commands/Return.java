package bcu.cmp5332.librarysystem.commands;

import bcu.cmp5332.librarysystem.model.*;
import bcu.cmp5332.librarysystem.data.LibraryData;
import bcu.cmp5332.librarysystem.main.LibraryException;

import java.io.IOException;
import java.time.LocalDate;

/**
 * Returns the book to the library and terminates the loan.
 *
 */
public class Return implements Command {
		/**
		 * The ID of the patron who is returning the loaned book.
		 */
		int patronID;
		/**
		 * The ID of the book which is being returned.
		 */
		int bookID;
    

    /**
     * Creates a new Return object with the following parameters:
     * @param patronID The ID of the patron returning the book.
     * @param bookID The ID of the book being returned.
     */
    public Return(int patronID, int bookID) {
        this.patronID = patronID;
        this.bookID = bookID;
    }
    
    /**
     * Returns a book.
     * @param library The library storing the books and patrons.
     * @param currentDate The current date.
     */
    @Override
    public void execute(Library library, LocalDate currentDate) throws LibraryException {
        Patron patron = library.getPatronByID(patronID);
        Book book = library.getBookByID(bookID);
        try {
        	if (book.getLoan().getPatron() == patron) {
            	patron.returnBook(book);
        	} else {
        		System.out.println(patron.getName()+" is not currently loaning "+book.getTitle()+".");
        	}
        	
        }catch(NullPointerException e) {
        	
        }
        try {
			LibraryData.store(library);
		} catch (IOException e) {
			e.printStackTrace();
		}
    }
}
