package bcu.cmp5332.librarysystem.model;

import java.time.LocalDate;

/**
 * Represents a loan of a book taken by a patron.
 * A loan can be taken and returned.
 */
public class Loan {
    
    /**
     * The patron who takes the loan.
     */
    private Patron patron;
    /**
     * The book being loaned.
     */
    private Book book;
    /**
     * The start date of the loan, i.e. the current date when the loan is made.
     */
    private LocalDate startDate;
    /**
     * The due date of the loan, i.e. the date before which the loan must be returned.
     */
    private LocalDate dueDate;
    /**
     * The current date when the loan is returned.
     */
    private LocalDate returnDate;
    /**
     * Denotes if the loan is active or not.
     */
    private boolean loanActive;

    /**
     * Creates a new loan with the following parameters:
     * @param patron The patron who takes the loan.
     * @param book The book being loaned.
     * @param startDate The start date of the loan.
     * @param dueDate The due date of the loan.
     * @param returnDate The date when the loan is returned.
     * @param loanActive This denotes if the loan is active or not.
     */
    public Loan(Patron patron, Book book, LocalDate startDate, LocalDate dueDate, LocalDate returnDate, boolean loanActive) {
    	this.patron = patron;
    	this.book = book;
    	this.startDate = startDate;
    	this.dueDate = dueDate;
    	this.returnDate = returnDate;
    	this.loanActive = loanActive;
    }

	/**
	 * Get the patron who took the loan.
	 * @return the patron who took the loan.
	 */
	public Patron getPatron() {
		return patron;
	}

	/**
	 * Changes the patron who took the loan.
	 * @param patron The patron who took the loan.
	 */
	public void setPatron(Patron patron) {
		this.patron = patron;
	}

	/**
	 * Get the book that has been loaned.
	 * @return the book that has been loaned.
	 */
	public Book getBook() {
		return book;
	}

	/**
	 * Changes the book that has been loaned.
	 * @param book The book that has been loaned.
	 */
	public void setBook(Book book) {
		this.book = book;
	}
	
	/**
	 * Get the start date of the loan.
	 * @return the start of the loan.
	 */
	public LocalDate getStartDate(){
		return startDate;
	}

	/**
	 * Get the due date of the loan.
	 * @return the due date of the loan.
	 */
	public LocalDate getDueDate() {
		return dueDate;
	}

	/**
	 * Changes the due date of the loan.
	 * @param dueDate The due date of the loan.
	 */
	public void setDueDate(LocalDate dueDate) {
		this.dueDate = dueDate;
	} 
	
	/**
	 * Get the date when the loan was returned.
	 * @return the date when the loan was returned.
	 */
	public LocalDate getReturnDate() {
		return returnDate;
	}

	/**
	 * Changes the date when the loan was returned to the current date.
	 */
	public void setReturnDate() {
		this.returnDate = LocalDate.now();
	}
	
	/**
	 * Get if the loan is active or not.
	 * @return
	 */
	public boolean getLoanActive() {
		return loanActive;
	}
	/**
	 * Changes if the loan is active or not.
	 * @param loanActive The status of the loan.
	 */
	public void setLoanActive(boolean loanActive) {
		this.loanActive = loanActive;
	}
	
	/**
	 * Get a string containing this loan's book's full title and this loan's start date and return date.
	 * @return a string containing this loan's book's full title and this loan's start date and return date.
	 */
	public String getDetails() {
		return this.book.getTitle() + "\nBorrowed: " + this.startDate + "\nReturned: " + this.returnDate +"\n~\n";
	}
    
    
}

