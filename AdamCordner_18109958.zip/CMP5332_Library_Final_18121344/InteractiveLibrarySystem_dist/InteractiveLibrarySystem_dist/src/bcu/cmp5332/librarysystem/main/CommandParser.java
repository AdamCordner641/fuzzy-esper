package bcu.cmp5332.librarysystem.main;

import bcu.cmp5332.librarysystem.commands.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
//import java.util.Arrays; //used in commented code

public class CommandParser {
    
    public static Command parse(String line) throws IOException, LibraryException {
        try {
            //System.out.println(line); //repeated code user doesn't need to see
            String[] parts = line.split(" ", 3);
            //System.out.println(Arrays.toString(parts)); //repeated code user doesn't need to see
            String cmd = parts[0];

            
            if (cmd.equals("addbook")) {
                BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
                System.out.print("Title: ");
                String title = br.readLine();
                System.out.print("Author: ");
                String author = br.readLine();
                System.out.print("Publisher: ");
                String publisher = br.readLine();
                System.out.print("Publication Year: ");
                String publicationYear = br.readLine();
                
                return new AddBook(title, author, publisher, publicationYear);
            } else if (cmd.equals("addpatron")) {
                //to do
            	BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
                System.out.print("Name: ");
                String name = br.readLine();
                System.out.print("Phone Number: ");
                String phoneno = br.readLine();
                
            	return new AddPatron(name, phoneno);
            } else if (cmd.equals("loadgui")) {
                return new LoadGUI();
            } else if (parts.length == 1) {
                if (line.equals("listbooks")) {
                    return new ListBooks();
                } else if (line.equals("listpatrons")) {
                    return new ListPatrons();
                } else if (line.equals("help")) {
                    return new Help();
                }
            } else if (parts.length == 2) {
                int id = Integer.parseInt(parts[1]);

                if (cmd.equals("showbook")) {
                    return new ShowBook(id);
                } else if (cmd.equals("showpatron")) {
                    //to do
                	return new ShowPatron(id);
                } else if (cmd.equals("hidebook")) { //new command
                	return new HideBook(id);
                } else if (cmd.equals("hidepatron")) { //new command
                	return new HidePatron(id);
                } else if (cmd.equals("loanhistory")) {
                	return new LoanHistory(id);
                }
            } else if (parts.length == 3) {
                int patronID = Integer.parseInt(parts[1]);
                int bookID = Integer.parseInt(parts[2]);

                if (cmd.equals("borrow")) {
                	//TODO: done
                    return new Borrow(patronID, bookID);
                } else if (cmd.equals("renew")) {
                    return new Renew(patronID, bookID);
                } else if (cmd.equals("return")) {
                    return new Return(patronID, bookID);
                }
            }
        } catch (NumberFormatException ex) {
  
        }

        throw new LibraryException("Invalid command.");
    }
}
