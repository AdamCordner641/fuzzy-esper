package bcu.cmp5332.librarysystem.commands;

import bcu.cmp5332.librarysystem.model.Book;
import bcu.cmp5332.librarysystem.model.Library;
import bcu.cmp5332.librarysystem.main.LibraryException;

import java.time.LocalDate;
import java.util.List;

/**
 * Lists all books in the library.
 *
 */
public class ListBooks implements Command {

    /**
     * Uses a loop to print the brief details of each book in the library.
     * @param library The library storing the books and patrons.
     * @param currentDate The current date.
     */
    @Override
    public void execute(Library library, LocalDate currentDate) throws LibraryException {
        List<Book> books = library.getBooks();
        int i = 0;
        for (Book book : books) {
        	if (!book.isHidden()) {
            	System.out.println(book.getDetailsShort());
            	i++;
        	}
        }
        System.out.println(i + " book(s)");
    }
}
