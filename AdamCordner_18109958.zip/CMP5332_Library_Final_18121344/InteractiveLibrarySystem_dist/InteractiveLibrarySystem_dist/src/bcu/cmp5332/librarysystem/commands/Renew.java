package bcu.cmp5332.librarysystem.commands;

import bcu.cmp5332.librarysystem.model.*;
import bcu.cmp5332.librarysystem.data.LibraryData;
import bcu.cmp5332.librarysystem.main.LibraryException;

import java.io.IOException;
import java.time.LocalDate;

/**
 * Renews a loan on a book.
 *
 */
public class Renew implements Command {
		/**
		 * The ID of the patron who is renewing their loan.
		 */
		int patronID;
		/**
		 * The ID of the book which is being renewed.
		 */
		int bookID;
    

    /**
     * Creates a new Renew object with the following parameters:
     * @param patronID The ID of the patron.
     * @param bookID The ID of the book.
     */
    public Renew(int patronID, int bookID) {
        this.patronID = patronID;
        this.bookID = bookID;
    }
    
    /**
     * Adds 7 days to the due date for this loan, renewing it for another week.
     * @param library The library storing the books and patrons.
     * @param currentDate The current date.
     */
    @Override
    public void execute(Library library, LocalDate currentDate) throws LibraryException {
        Patron patron = library.getPatronByID(patronID);
        Book book = library.getBookByID(bookID);
        LocalDate dueDate =  currentDate.plusDays(library.getLoanPeriod());
        try {
        	patron.renewBook(book, dueDate);

        }catch(NullPointerException e) { 
        	
        }
        try {
			LibraryData.store(library);
		} catch (IOException e) {
			e.printStackTrace();
		}
    }
}
