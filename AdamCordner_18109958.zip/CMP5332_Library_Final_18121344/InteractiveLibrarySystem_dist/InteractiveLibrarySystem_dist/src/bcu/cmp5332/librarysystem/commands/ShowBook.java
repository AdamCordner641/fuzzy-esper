package bcu.cmp5332.librarysystem.commands;

import bcu.cmp5332.librarysystem.model.Book;
import bcu.cmp5332.librarysystem.model.Library;
import bcu.cmp5332.librarysystem.main.LibraryException;

import java.time.LocalDate;

/**
 * Shows details regarding a given book.
 *
 */
public class ShowBook implements Command {
	
	/**
	 * The ID of the book which is being detailed.
	 */
	private final int id;

    /**
     * Creates a new ShowBook object.
     * @param id The ID of the book being detailed.
     */
    public ShowBook(int id) {
        this.id = id;
    }
	
    /**
     * Displays the long details of the book.
     * @param library The library storing the books and patrons.
     * @param currentDate The current date.
     */
    @Override
    public void execute(Library library, LocalDate currentDate) throws LibraryException {
        Book book = library.getBookByID(id);
        System.out.println(book.getDetailsLong());
    }
}
