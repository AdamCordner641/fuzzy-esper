package bcu.cmp5332.librarysystem.tests;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;

import bcu.cmp5332.librarysystem.model.*;


class Testing {
	
	private LocalDate startDate;
    private LocalDate dueDate;
    private LocalDate returnDate;
    
	private Patron patron = new Patron(0, "name","phoneno", null, false);
	private Book book = new Book(0, "title","author", "publisher", "publicationyear", false);
	private Loan loan = new Loan(patron, book, startDate,  dueDate, returnDate, true);
	
	@Test
	public void patronHasPhoneNo() {	
		assertEquals(patron.getPhone(), "phoneno");
	}
	
	@Test
	public void bookHasPublisher() {
		assertEquals(book.getPublisher(), "publisher");
	}
	
	@Test
	public void bookHasLoan() {
		book.setLoan(loan);
		assertTrue(book.isOnLoan());
	}
	
	@Test
	public void bookCanReturn() {
		book.setLoan(loan);
		book.returnToLibrary();
		assertFalse(book.isOnLoan());
	}
	
	   
}
