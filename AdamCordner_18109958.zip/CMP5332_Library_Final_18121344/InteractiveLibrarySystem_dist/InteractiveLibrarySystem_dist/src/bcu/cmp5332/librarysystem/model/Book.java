package bcu.cmp5332.librarysystem.model;

import bcu.cmp5332.librarysystem.main.LibraryException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Represents a book in the library.
 * A book can be borrowed by a patron.
 */
public class Book {
    
    /**
     * The unique ID of the book.
     */
    private int id;
    /**
     * The full title of the book.
     */
    private String title;
    /**
     * The author of the book's full name.
     */
    private String author;
    /**
     * The company who published the book.
     */
    private String publisher;
    /**
     * The year the book was published.
     */
    private String publicationYear;
    /**
     * Denotes if the book is hidden or not from the system.
     */
    private boolean hidden;
    /**
     * Lists all previous and current loans involving the book.
     */
    private final List<Loan> loans = new ArrayList<>();

    /**
     * Creates a new book with the following parameters:
     * @param id This is the unique ID of the book.
     * @param title This is the full title of the book.
     * @param author This is the author of the book's full name.
     * @param publisher This is the company who published the book.
     * @param publicationYear This is the year the book was published.
     * @param hidden This denotes if the book is hidden or not from the system.
     */
    public Book(int id, String title, String author, String publisher, String publicationYear, boolean hidden) { 
        this.id = id;
        this.title = title;
        this.author = author;
        this.setPublisher(publisher);
        this.publicationYear = publicationYear;
        this.hidden = hidden;
    }
    
    /**
     * Gets the hidden status of this book.
     * @return this book's hidden status.
     */
    public boolean isHidden() {
        return hidden;
    }

    /**
     * Changes the hidden status of this book to true.
     */
    public void hideBook() {
    	if(this.isOnLoan()) {
    		this.hidden = true;
    		System.out.println("Book #" + this.getId() + " has been removed.");
    	}else {
    		System.out.println("Cannot remove Book #" + this.getId() + ". This book is on loan.");
    	}
    }

    /**
     * Gets the unique ID of this book.
     * @return this book's unique ID.
     */
    public int getId() {
        return id;
    }

    /**
     * Changes the unique ID of this book.
     * @param id This book's unique ID.
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Gets the full title of this book.
     * @return this book's full title.
     */
    public String getTitle() {
        return title;
    }

    /**
     * Changes the full title of this book.
     * @param title This book's full title.
     */
    public void setTitle(String title) {
        this.title = title;
    }
    
    /**
     * Gets this book's author's full name.
     * @return this book's author's full name.
     */
    public String getAuthor() {
        return author;
    }
    
    /** 
     * Changes this book's author's full name.
     * @param author This book's author's full name.
     */
    public void setAuthor(String author) {
        this.author = author;
    }

    /**
     * Gets this book's publication year.
     * @return this book's publication year.
     */
    public String getPublicationYear() {
        return publicationYear;
    }

    /**
     * Changes this book's publication year.
     * @param publicationYear This book's publication year.
     */
    public void setPublicationYear(String publicationYear) {
        this.publicationYear = publicationYear;
    }
	
    /**
     * Gets a string containing this book's unique ID and full title.
     * @return a string containing this book's unique ID and full title.
     */
    public String getDetailsShort() {
        return "Book #" + id + " - " + title;
    }

    /**
     * Gets a string containing this book's unique ID, full title, author's full name, publisher, publication year, and if this book is currently on loan.
     * @return a string containing this book's unique ID, full title, author's full name, publisher, publication year, and if this book is currently on loan.
     */
    public String getDetailsLong() {
    	if(this.isOnLoan()) {
	        return "Book #" + id + " - " + title + "\nBy " + author + ", Published by " + publisher + " in " + publicationYear
	        		+ "\n~~~~\nOn loan by: " + getLoan().getPatron().getName();
    	}else {
    		return "Book #" + id + " - " + title + "\nBy " + author + ", Published by " + publisher + " in " + publicationYear;
    	}
    }
    
    /**
     * Get if this book is currently on loan.
     * @return true if this book is currently on loan and false if it is not.
     */
    public boolean isOnLoan() {
        return (this.getLoan() != null);
    }
    
    /**
     * Get if this book is currently on loan.
     * @return if this book is currently on loan or available.
     */
    public String getStatus() {
        if(this.isOnLoan()) {
        	return "On Loan";
        }else {
        	return "Available";
        }
    }

    /**
     * Get this book's due date if it is on loan.
     * @return this book's due date if it is on loan.
     */
    public LocalDate getDueDate() {
        return this.getLoan().getDueDate();
    }
    
    /**
     * Changes this book's due date if it is on loan.
     * @param dueDate This book's due date.
     * @throws LibraryException
     */
    public void setDueDate(LocalDate dueDate) throws LibraryException {
    	this.getLoan().setDueDate(dueDate);
    }

    /**
     * Get this book's current loan if it is on loan.
     * @return this book's current loan.
     */
    public Loan getLoan() {
    	Loan returnLoan = null;
    	for(Loan loan: this.loans) {
    		if(loan.getLoanActive()) {
    			returnLoan = loan;
    		}
    	}
    	return returnLoan;
    }

    /**
     * Change this book's current, most recent loan.
     * @param loan This book's current, most recent loan.
     */
    public void setLoan(Loan loan) {
        this.loans.add(loan);
    }

    /**
     * Returns this book if it is on loan by setting this loan's return date to the current date and setting this loan's status to inactive.
     */
    public void returnToLibrary() {
        this.getLoan().setReturnDate();
        this.getLoan().setLoanActive(false);
    }
    
    /**
     * Get this book's loan history.
     * @return this book's list of loans.
     */
    public List<Loan> getLoans() {
        return loans;
    }

	/**
	 * Get this books's publisher.
	 * @return this book's publisher.
	 */
	public String getPublisher() {
		return publisher;
	}

	/**
	 * Changes this book's publisher.
	 * @param publisher This book's publisher.
	 */
	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}
}
