package bcu.cmp5332.librarysystem.commands;

import bcu.cmp5332.librarysystem.data.LibraryData;
import bcu.cmp5332.librarysystem.main.LibraryException;
import bcu.cmp5332.librarysystem.model.Patron;
import bcu.cmp5332.librarysystem.model.Library;

import java.io.IOException;
import java.time.LocalDate;

/**
 * Hides, i.e. "deletes", a patron.
 *
 */
public class HidePatron implements Command {

	/**
	 * The ID of the patron being hid.
	 */
	private final int id;

    /**
     * Creates a new HidePatron object with the following parameters:
     * @param id The ID of the patron being hid,
     */
    public HidePatron(int id) {
        this.id = id;
    }
	
    /**
     * Hides a patron.
     * Gets the patron ID from the HidePatron object.
     * @param library The library storing the books and patrons.
     * @param currentDate The current date.
     */
    @Override
    public void execute(Library library, LocalDate currentDate) throws LibraryException {
        Patron patron = library.getPatronByID(id);
        patron.hidePatron();
        try {
			LibraryData.store(library);
		} catch (IOException e) {
			e.printStackTrace();
		}
    }
}
