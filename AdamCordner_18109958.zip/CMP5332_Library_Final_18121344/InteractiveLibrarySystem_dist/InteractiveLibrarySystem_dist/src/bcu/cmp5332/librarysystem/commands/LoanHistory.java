package bcu.cmp5332.librarysystem.commands;

import bcu.cmp5332.librarysystem.model.Patron;
import bcu.cmp5332.librarysystem.model.Book;
import bcu.cmp5332.librarysystem.model.Library;
import bcu.cmp5332.librarysystem.model.Loan;
import bcu.cmp5332.librarysystem.main.LibraryException;

import java.time.LocalDate;

/**
 * Displays all previous loans for a given patron.
 *
 */
public class LoanHistory implements Command {

	/**
	 * The ID of the patron who is having their loan history displayed.
	 */
	private final int id;

	/**
	 * Creates a new LoanHistory object with the following parameters:
	 * @param id The ID of the patron.
	 */
	public LoanHistory(int id) {
		this.id = id;
	}

	/**
	 * Uses loops to display all inactive loans for this patron.
     * @param library The library storing the books and patrons.
     * @param currentDate The current date.
	 */
	@Override
	public void execute(Library library, LocalDate currentDate) throws LibraryException {
		Patron patron = library.getPatronByID(id);
		int i = 0;
		System.out.println(patron.getName());
		for (Book book : library.getBooks()) {
			for(Loan loan : book.getLoans()) {
				if(!loan.getLoanActive() && loan.getPatron() == patron){
					i++;
					System.out.println(loan.getDetails());
				}
			}
		}System.out.println(i + " previous loan(s)");
	}
}
