package bcu.cmp5332.librarysystem.commands;

import bcu.cmp5332.librarysystem.data.LibraryData;
import bcu.cmp5332.librarysystem.main.LibraryException;
import bcu.cmp5332.librarysystem.model.Patron;
import bcu.cmp5332.librarysystem.model.Book;
import bcu.cmp5332.librarysystem.model.Library;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;


/**
 * Adds a patron to the library.
 *
 */
public class AddPatron implements Command {

    /**
     * The name of the patron.
     */
    private final String name;
    /**
     * The phone number of the patron.
     */
    private final String phone;

    /**
     * Creates a new AddPatron object with the following parameters:
     * @param name The patron's name.
     * @param phone The patron's phone number.
     */
    public AddPatron(String name, String phone) {
        this.name = name;
        this.phone = phone;
    }

    /**
     * Adds a patron to the library.
     * Autogenerates the unique ID for the patron.
     * Gets the patron name and phone number from the AddPatron object.
     * Defaults status of patron as hidden to false.
     * @param library The library storing the books and patrons.
     * @param currentDate The current date.
     */
    @Override
    public void execute(Library library, LocalDate currentDate) throws LibraryException {
    	int lastIndex = library.getPatrons().size() - 1; 
    	int maxId = library.getBooks().get(lastIndex).getId();
    	List<Book> bookLoans = new ArrayList<>();
    	Patron patron = new Patron(++maxId, name, phone, bookLoans, false);
    	library.addPatron(patron);
    	System.out.println("Patron " + patron.getId() + " added");
    	try {
			LibraryData.store(library);
		} catch (IOException e) {
			e.printStackTrace();
		}
    }
}
