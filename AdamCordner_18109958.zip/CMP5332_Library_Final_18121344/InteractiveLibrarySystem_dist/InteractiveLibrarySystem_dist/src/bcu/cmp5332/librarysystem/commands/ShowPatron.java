package bcu.cmp5332.librarysystem.commands;

import bcu.cmp5332.librarysystem.model.Patron;
import bcu.cmp5332.librarysystem.model.Library;
import bcu.cmp5332.librarysystem.main.LibraryException;

import java.time.LocalDate;

/**
 * Shows details regarding a given patron.
 *
 */
public class ShowPatron implements Command {
	
	/**
	 * The ID of the patron being detailed.
	 */
	private final int id;

    /**
     * Creates a ShowPatron object with the following parameters:
     * @param id The ID of the patron being detailed.
     */
    public ShowPatron(int id) {
        this.id = id;
    }
	
    /**
     * Displays the details of the patron.
     * @param library The library storing the books and patrons.
     * @param currentDate The current date.
     */
    @Override
    public void execute(Library library, LocalDate currentDate) throws LibraryException {
        Patron patron = library.getPatronByID(id);
        System.out.println(patron.getPatrons());
    }
}
