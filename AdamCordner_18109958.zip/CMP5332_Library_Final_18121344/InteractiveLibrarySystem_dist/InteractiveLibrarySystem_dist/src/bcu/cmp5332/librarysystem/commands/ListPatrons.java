package bcu.cmp5332.librarysystem.commands;

import bcu.cmp5332.librarysystem.model.Patron;
import bcu.cmp5332.librarysystem.model.Library;
import bcu.cmp5332.librarysystem.main.LibraryException;

import java.time.LocalDate;
import java.util.List;

/**
 * Lists all the patrons.
 *
 */
public class ListPatrons implements Command {

    /**
     * Uses a loop to print each of the patrons.
     * @param library The library storing the books and patrons.
     * @param currentDate The current date.
     */
    @Override
    public void execute(Library library, LocalDate currentDate) throws LibraryException {
        List<Patron> patrons = library.getPatrons();
        int i = 0;
        for (Patron patron : patrons) {
        	if (!patron.isHidden()) {
            	System.out.println(patron.getPatrons());
            	i++;
        	}
        }
        System.out.println(i + " patrons(s)");
    }
}
