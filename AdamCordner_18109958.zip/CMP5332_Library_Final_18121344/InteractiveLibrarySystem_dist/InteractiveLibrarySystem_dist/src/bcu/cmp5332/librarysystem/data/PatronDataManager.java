package bcu.cmp5332.librarysystem.data;

import bcu.cmp5332.librarysystem.model.*;
import bcu.cmp5332.librarysystem.main.LibraryException;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class PatronDataManager implements DataManager {

    private final String RESOURCE = "./resources/data/patrons.txt";
    
    @Override
    public void loadData(Library library) throws IOException, LibraryException {
        // TODO: implementation here
    	try (Scanner sc = new Scanner(new File(RESOURCE))) {
            int line_idx = 1;
            while (sc.hasNextLine()) {
                String line = sc.nextLine();
                String[] properties = line.split(SEPARATOR, -1);
                try {
                    int id = Integer.parseInt(properties[0]);
                    String name = properties[1];
                    String phoneno = properties[2];
                    String booksText = properties[3]; //assume string is in form 15,16,17  
                    List<Book> bookLoans = new ArrayList<>();
                    if(booksText.isEmpty()) {
                    	
                    }else {
                    	String[] bookslist = booksText.split(",");
	                    for(String bookID : bookslist) {
	                    	Book book = library.getBookByID(Integer.parseInt(bookID));
	                    	bookLoans.add(book);
	                    }
                    }
                    String hiddenText = properties[4];
                    boolean hidden = Boolean.parseBoolean(hiddenText);
					Patron patron = new Patron(id, name, phoneno, bookLoans, hidden);
                    library.addPatron(patron);
                } catch (NumberFormatException ex) {
                    throw new LibraryException("Unable to parse patron id " + properties[0] + " on line " + line_idx + "\nError: " + ex);
                }
                line_idx++;
            }
        }
    }

    @Override
    public void storeData(Library library) throws IOException {
        // TODO: implementation here
    	try (PrintWriter out = new PrintWriter(new FileWriter(RESOURCE))) {
            for (Patron patron : library.getPatrons()) {
                out.print(patron.getId() + SEPARATOR);
                out.print(patron.getName() + SEPARATOR);
                out.print(patron.getPhone() + SEPARATOR);
                out.print(patron.getLoansAsString() + SEPARATOR); //loans need writing as a list in form "1,2,3"
                out.print(patron.isHidden() + SEPARATOR);
                out.println();
            }
        }
    }
}
