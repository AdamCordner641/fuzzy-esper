package bcu.cmp5332.librarysystem.commands;

import bcu.cmp5332.librarysystem.model.*;
import bcu.cmp5332.librarysystem.data.LibraryData;
import bcu.cmp5332.librarysystem.main.LibraryException;

import java.io.IOException;
import java.time.LocalDate;

/**
 * Borrows a book from the library for a patron.
 *
 */
public class Borrow implements Command {
		/**
		 * The patron borrowing the book.
		 */
		int patronID;
		/**
		 * The book being borrowed.
		 */
		int bookID;
    

    /**
     * Creates a new Borrow object with the following parameters:
     * @param patronID The patron borrowing the book.
     * @param bookID The book being borrowed.
     */
    public Borrow(int patronID, int bookID) {
        this.patronID = patronID;
        this.bookID = bookID;
    }
    
    /**
     * Borrows a book from the library for a patron.
     * Gets the patron ID and book ID from the Borrow object.
     * Calculates the due date as current date plus one week.
     * @param library The library storing the books and patrons.
     * @param currentDate The current date.
     */
    @Override
    public void execute(Library library, LocalDate currentDate) throws LibraryException {
        Patron patron = library.getPatronByID(patronID);
        Book book = library.getBookByID(bookID);
        LocalDate dueDate =  currentDate.plusDays(library.getLoanPeriod());
        try {
        	patron.borrowBook(book, dueDate);

        }catch(NullPointerException e) { 
        	
        }
        try {
			LibraryData.store(library);
		} catch (IOException e) {
			e.printStackTrace();
		}
    }
}
